export const APP_NAME = "WebAppStore";

export const CATEGORIES = [
  "Games",
  "Productivity",
  "Education",
  "Tools",
  "Lifestyle",
  "Entertainment",
  "Social",
  "Health",
  "Music",
  "Photography",
  "Other"
];